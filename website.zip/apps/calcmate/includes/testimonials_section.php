<!-- Our Testimonial  -->

<section id="testimonial">
    <div class="container">
        <div class="row">
            <div class="main_testimonial_text center-content">
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">Emskaro, - CalcMate Pro User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">Kelechi Obioma, CalcMate Pro User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">Jacqueline Anyanwu, CalcMate Free User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">George, CalcMate Free User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>
                    <a href="">Victor, CalcMate Free User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">Oluchi, CalcMate Free User</a>
                </div>
                <div class="col-md-12 col-sm-12 single_testimonial_text item">
                    <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris quis nostrud nisi ut aliquip ex ea commodo consequat.</p>-->
                    <a href="">Anthony Ojigwe, CalcMate Free User</a>
                </div>
            </div>
        </div>
    </div>
</section>