<!-- Download Section  -->

<section id="downloadApps">
    <div class="container">
        <div class="row">
            <div class="download_heading_text center-content">
                <h1>Download the App</h1>
                <p>Download CalcMate straight to your device Now!.</p>

                <div class="down_text_des wow fadeInUp" data-wow-duration="1.5s">
                    <a href="javascript:void(0)"><img src="images/d1.png" alt="" /></a>
                    <a href=""><img src="images/d2.png" alt="" /></a>
                    <a href="javascript:void(0)"><img src="images/d3.png" alt="" /></a>
                </div>
            </div>
        </div>
    </div>
</section>