<footer id="footer" class="center-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="socail_bookmark">
                    <a href="https://twitter.com/gigabytedevsinc"><i class="fa fa-twitter"></i></a>
                    <a href="https://facebook.com/gigabytedevelopersinc"><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                    <a href=""><i class="fa fa-google-plus"></i></a>
                    <a href="https://instagram.com/gigabytedevelopersinc"><i class="fa fa-instagram"></i></a>
                    <a href=""><i class="fa fa-pinterest-p"></i></a>
                    <a href=""><i class="fa fa-dribbble"></i></a>
                </div>
            </div>
            <div class="col-md-12 col-sm-12">
                <div class="copyright_text">
                    <p class=" wow zoomIn" data-wow-duration="1s">Made with <i class="fa fa-heart"></i> by <a href="../../">Gigabyte Developers Incorporated</a>2017, All Rights Reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>