<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="./js/jquery/jquery.js"></script>

<script src="./js/script.js"></script>


<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="./js/bootstrap/bootstrap.min.js"></script>
<script src="./js/fancybox/jquery.fancybox.pack.js"></script>
<script src="./js/nivo-lightbox/nivo-lightbox.min.js"></script>
<script src="./js/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBL6gbhsnCEt4FS9D6BBl3mZO1xy-NcwpE&sensor=false"></script>
<script src="./js/jquery-easing/jquery.easing.1.3.js"></script>
<script src="./js/superslide/jquery.superslides.js"></script>
<script src="./js/wow/wow.min.js"></script>