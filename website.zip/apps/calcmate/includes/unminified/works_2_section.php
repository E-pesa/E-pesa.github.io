<section id="works_2">
    <div class="container">
        <div class="row">
            <div class="works_2_content">
                <div class="col-sm-4 col-xs-12">
                    <div class="works_2_iphone center-content">
                        <img src="./images/iphone1.png" alt="" />
                    </div>
                </div>
                <div class="col-sm-8 col-xs-12 top-margin">
                    <div class="row">
                        <div class="single_works_2_content wow fadeInRight" data-wow-duration="1.5s">
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-crop"></i>
                                    <div class="text_deatels">
                                        <h3>Clean and Responsive</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-cube"></i>
                                    <div class="text_deatels">
                                        <h3>Nice User Interface</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-magic"></i>
                                    <div class="text_deatels">
                                        <h3>Awesome User Experience</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-code-fork"></i>
                                    <div class="text_deatels">
                                        <h3>Graphical Representation</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-rocket"></i>
                                    <div class="text_deatels">
                                        <h3>Effective Tour Guide</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="single_works_2_text">
                                    <i class="fa fa-database"></i>
                                    <div class="text_deatels">
                                        <h3>100% Accuracy</h3>
                                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>