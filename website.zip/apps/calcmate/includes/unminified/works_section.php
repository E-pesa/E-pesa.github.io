<!-- Our Works Section -->

<section id="works" class="center-content">
    <div class="container">
        <div class="row">
            <div class="works_content text-center">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration=".5s">
                        <i class="fa fa-crop"></i>
                        <h3>Clean and Responsive</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration=".8s">
                        <i class="fa fa-cube"></i>
                        <h3>100% Efficiency</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="1.2s">
                        <i class="fa fa-magic"></i>
                        <h3>Nice User Interface</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="1.5s">
                        <i class="fa fa-code-fork"></i>
                        <h3>Awesome User Experience</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="1.9s">
                        <i class="fa fa-rocket"></i>
                        <h3>Graphical Representation</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="2.3s">
                        <i class="fa fa-database"></i>
                        <h3>Effective Tour Guide</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="2.6s">
                        <i class="fa fa-rocket"></i>
                        <h3>100% Accuracy</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single_works_text wow fadeInLeft" data-wow-duration="2.9s">
                        <i class="fa fa-database"></i>
                        <h3>Free For All</h3>
                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas at nibh orci.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>