<!-- Video Section -->

<section id="video_icon">
    <div class="video_overlay">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <div class="video_text center-content">
                        <a href="https://www.youtube.com/embed/zpOULjyy-n8" class="youtube-media">
                            <img src="images/play.png" alt="" />
                        </a>
                        <h5>Watch the full Tour Guide video</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>