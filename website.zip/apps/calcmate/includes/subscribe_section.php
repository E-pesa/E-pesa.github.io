<!-- Subscribe Section  -->

<section id="subscribe">
    <div class="subcribe_overlay">
        <div class="container">
            <div class="row">
                <div class="subscribe_heading_text center-content">
                    <div class="subscribe_heading_title wow fadeIn" data-wow-duration="1s">
                        <h1>Subscribe Now</h1>
                        <p>Get the latest news, offers and version updates of CalcMate.</p>
                    </div>

                    <div class="subcribe_form center-content">
                        <input type="text" placeholder="Email Address">
                        <input type="submit" value="Subscribe">
                    </div>
                </div>


            </div>
        </div>
    </div>
</section>