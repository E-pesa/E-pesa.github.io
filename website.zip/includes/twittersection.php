<section id=twitter class=parallax> 
    <div> 
        <a class=twitter-left-control href=#twitter-carousel role=button data-slide=prev><i class="fa fa-angle-left"></i></a> 
        <a class=twitter-right-control href=#twitter-carousel role=button data-slide=next><i class="fa fa-angle-right"></i></a> 
        <div class=container> 
            <div class=row> 
                <div class="col-sm-8 col-sm-offset-2"> 
                    <div class="twitter-icon text-center"> 
                        <span class="glyphicon glyphicon-bullhorn" aria-hidden=true></span> 
                        <h4>Testimonials</h4> 
                   </div> 

                   <div id=twitter-carousel class="carousel slide" data-ride=carousel> 
                        <div class=carousel-inner> 
                            <div class="item active wow fadeIn" data-wow-duration=1000ms data-wow-delay=300ms> 
                                <p>waploaj is the best tech company that offer a good advises
                                <a href=javascript:void()><span>#helixframework #joomla</span> http://bit.ly/1qlgwav</a></p> 
                           </div> 

                            <div class=item> 
                                <p>They are very oriented with their work 
                                <a href=javascript:void()><span>#helixframework #joomla</span> http://bit.ly/1qlgwav</a></p> 
                            </div> 

                            <div class=item> 
                                <p>they have astanish desing and the imagination ooh boy the sky is the limit 
                                <a href=javascript:void()><span>#helixframework #joomla</span> http://bit.ly/1qlgwav</a></p> 
                            </div> 
                        </div> 
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
</section>