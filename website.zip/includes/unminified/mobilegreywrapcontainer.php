<div id=greywrap>
    <div class=container>
        <div class=row>
            <div class="col-lg-8 centered"> <img class=img-responsive alt=Hire src=./images/macbook.png align> </div>
            <div class=col-lg-4>
                <h2>Hire Us Now!</h2></div>
            <div class=col-lg-4>
                <p>Do you want our team at Gigabyte Developers Incorporated to do the work for you? Of course you want to, because we are awesome and 100% professional!. Here at Gigabyte Developers Incorporated, we work very hard every day to program lots of stuffs and to craft pixel perfect sites!. So, click on the button below to get started</p>
            </div>
            <p> <a href=./contact target=_blank class="btns btns-success">Contact Us</a></p>
            <div class=clearfix></div>
        </div>
        <!-- row -->
    </div>
    <br>
    <br> </div>
<div class=clearfix> </div>
