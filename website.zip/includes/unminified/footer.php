<footer id=footer>
    <div class="fadeInUp footer-top wow" data-wow-delay=300ms data-wow-duration=1000ms>
        <div class="container text-center">
            <div class=footer-logo>
                <a href=index><img alt=logo class=img-responsive src=./images/gigalogo.png></a>
            </div>
            <div class=social-icons>
                <ul>
                    <li><a href=https://www.twitter.com/gigabytedevsinc class=twitter target=_blank><i class="fa fa-twitter"></i></a>
                        <li><a href=https://www.facebook.com/gigabytedevelopersinc class=facebook target=_blank><i class="fa fa-facebook"></i></a>
                            <li><a href=https://plus.google.com/+GigabyteDevelopers class=googleplus target=_blank><i class="fa fa-google-plus"></i></a>
                                <li><a href=https://pinterest.com/gigabytedevsinc class=pinterest target=_blank><i class="fa fa-pinterest"></i></a>
                                    <li><a href=skype:emmanuel.nwokoma?call class=skype><i class="fa fa-skype"></i></a>
                                        <li><a href=https://www.linkedin.com/in/gigabytedevelopersinc class=linkedin target=_blank><i class="fa fa-linkedin"></i></a></ul>
            </div>
        </div>
    </div>
    <div class=footer-bottom>
        <div class=container>
            <div class=row>
                <div class=col-sm-6>
                    <p>Copyright © 2015-2017 </div>
            </div>
        </div>
    </div>
</footer>
