<head>
<!-- <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6834003782592739",
    enable_page_level_ads: true
  });
</script> -->
  <meta name="google-site-verification" content="RjAgqUgYfT94lQ7oGZqqRI87NeSdR_6fecSUipiGBmg" />
  <meta name="msvalidate.01" content="F39E6D2A441B34A5BCA816D83B967BDF" />
  <!-- <meta property="og:image" content="https://www.facebook.com/gigabytedevelopersinc/photos/a.1676965692579485.1073741825.1676948882581166/1677029205906467/?type=3&theater" /> -->
  <meta property="og:image:secure_url" content="https://raw.githubusercontent.com/gigabytedevelopers/website/master/thumbnail.png" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="Gigabyte Developers Incorporated">
  <meta property="og:title" content="Gigabyte Developers Incorporated | Home" />
  <meta property="og:description" content="Official Homepage of Gigabyte Developers Incorporated" />
  <meta property="og:image" itemprop="image" content="https://raw.githubusercontent.com/gigabytedevelopers/website/master/thumbnail.png" />
  <meta property="og:image:url" itemprop="image" content="https://raw.githubusercontent.com/gigabytedevelopers/website/master/thumbnail.png" />
  <meta property="og:image:type" content="image/png" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Official Homepage of Gigabyte Developers Incorporated">
  <meta name="author" content="Gigabyte Developers Incorporated">
  <meta name="theme-color" content="#028fcc">
  <title>waploaj Incorporated | Home</title>
  <link href="./css/bootstrap.min.css" rel="stylesheet">
  <link href="./css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="./css/lightbox.css"> 
  <link id="css-preset" href="./css/presets/preset1.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
  <link rel="shortcut icon" href="./images/gigaicon.ico">
  <!-- <noscript>
  <meta http-equiv="refresh" content="0;url=mobile">
  </noscript> -->
</head>