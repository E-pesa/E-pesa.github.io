<footer id=footer> 
    <div class="fadeInUp footer-top wow" data-wow-delay=300ms data-wow-duration=1000ms>
         <div class="container text-center"> 
             <!-- <div class=footer-logo> 
                 <a href=index>
                     <img alt=logo class=img-responsive src=./images/giga_round.png></a>
             </div> -->
                 <div class=social-icons>
                   <ul> 
                       <li><a href=https://www.twitter.com/duurhla class=twitter target=_blank><i class="fa fa-twitter"></i></a>
                       <li><a href="htttps://www.github.com/waploaj" class=github target=_blank><i class="fa fa-github"></i></a></li>
                       
                    </ul> 
                </div> 
            </div> 
  </div> 
  
        <div class=footer-bottom> 
            <div class=container>
                 <div class=row>
                     <div class=col-sm-6>
                          <p>Copyright © 2015 - <?php echo date("y");?> waploaj inc. All Rights Resevered 
                       </div>
                        <!-- <a class=col-lg-6> <p><a href=<?php if ($current_file === 'index.php') { echo 'mobile'; } elseif ($current_file === 'loggedin.php') { echo 'loggedinonmobile'; }?> class="wow fadeInRightBig btns btns-success" style="color:#FFFFFF;text-decoration:none;float: right;">Mobile Version -->
                      </p>
                       </a>
                  </div> 
              </div> 
          </div>
      </div> 
</footer>