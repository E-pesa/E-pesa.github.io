<head>
<!-- <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6834003782592739",
    enable_page_level_ads: true
  });
</script> -->
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Official Homepage of waploaj Developers Incorporated">
  <meta name="author" content="waploaj Developers Incorporated">
  <meta name="theme-color" content="#028fcc">
  <title>waploaj Incorporated | Home</title>
  <link href="./css/bootstrap.min.css" rel="stylesheet">
  <link href="./css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="./css/lightbox.css"> 
  <link id="css-preset" href="./css/presets/preset1.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
  <link rel="shortcut icon" href="./images/gigaicon.ico">
  <!-- <noscript>
  <meta http-equiv="refresh" content="0;url=mobile">
  </noscript> -->
  <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="6cf37e2c-8858-4aca-a6c6-25068280afcb";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</head>