<footer id="footer">
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <p>Copyright &copy; 2016-2017  Incorporated. All Rights Resevered</p>
          </div>
        </div>
      </div>
    </div>
</footer>