<footer>
	&copy; Gigabyte Developers Incorporated 2016. All rights reserved.
</footer>