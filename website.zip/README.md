Open-Source <a href="http://gigabytedevelopersinc.com">Gigabyte Developers Incorporated</a> website
====================================================================

[![Crates.io](https://img.shields.io/crates/l/rustc-serialize.svg)](#)
[![DUB](https://img.shields.io/badge/downloads-1k%2Fweek-green.svg)]()
[![DUB](https://img.shields.io/badge/Powered%20by-PHP-blue.svg)]()

![Gigabyte-Developers](https://raw.githubusercontent.com/gigabytedevelopers/website/master/banner1.png)
![Gigabyte-Developers](https://raw.githubusercontent.com/gigabytedevelopers/website/master/banner2.png)

<h1><strong>About The CEO and Co-Founders</strong></h1>
<a href="http://facebook.com/austin.nwokoma.9" target="_blank"><img src="https://facebookbrand.com/wp-content/themes/fb-branding/prj-fb-branding/assets/images/fb-art.png" alt="" width="50px"/></a>
<a href="http://instagram.com/emmanwokoma" target="_blank"><img src="https://image.flaticon.com/icons/png/128/174/174855.png" alt="" width="50px"/></a>
<a href="http://twitter.com/enwokoma" target="_blank"><img src="http://icons.iconarchive.com/icons/graphicloads/rounded-social-media/512/twitter-icon.png" alt="" width="50px"/></a>
<a href="http://linkedin.com/in/emmanuelnwokoma" target="_blank"><img src="http://www.iconsdb.com/icons/preview/caribbean-blue/linkedin-6-xxl.png" alt="" width="50px"/></a>
<a href="https://plus.google.com/u/0/+EmmanuelNwokoma" target="_blank"><img src="http://donnaloustevens.com/wp-content/themes/donnaloustevens/images/google%20plus.png" alt="" width="50px"/></a>

![Gigabyte-Developers](https://raw.githubusercontent.com/gigabytedevelopers/website/master/banner4.png)

<h1><strong>About Gigabyte Developers Incorporated (The Company)</strong></h1>
<a href="http://facebook.com/gigabytedevelopersinc" target="_blank"><img src="https://facebookbrand.com/wp-content/themes/fb-branding/prj-fb-branding/assets/images/fb-art.png" alt="" width="50px"/></a>
<a href="http://instagram.com/gigabytedevelopersinc" target="_blank"><img src="https://image.flaticon.com/icons/png/128/174/174855.png" alt="" width="50px"/></a>
<a href="http://twitter.com/gigabytedevsinc" target="_blank"><img src="http://icons.iconarchive.com/icons/graphicloads/rounded-social-media/512/twitter-icon.png" alt="" width="50px"/></a>
<a href="http://linkedin.com/in/gigabytedevelopersinc" target="_blank"><img src="http://www.iconsdb.com/icons/preview/caribbean-blue/linkedin-6-xxl.png" alt="" width="50px"/></a>
<a href="https://plus.google.com/u/0/+GigabyteDevelopers" target="_blank"><img src="http://donnaloustevens.com/wp-content/themes/donnaloustevens/images/google%20plus.png" alt="" width="50px"/></a>

![Gigabyte-Developers](https://raw.githubusercontent.com/gigabytedevelopers/website/master/banner5.png)

![Gigabyte-Developers](https://raw.githubusercontent.com/gigabytedevelopers/website/master/banner3.png)
