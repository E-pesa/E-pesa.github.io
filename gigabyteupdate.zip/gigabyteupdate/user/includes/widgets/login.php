<div class="widget">
	<h2>Log in/Register</h2>
	<div class="inner">
		<form action="login.php" method="POST">
			<ul	id="login">
				<li>
					Username:<br>
					<input type="text" name="username">
				</li>
				<li>
					Password:<br>
					<input type="password" name="password">
				</li>
				<li>
					<input type="submit" value="Logi in">
				</li>
				<li>
					<a href="register.php">Register</a>
				</li>
				<li>
					Forgot <a href="recover.php?mode=username">username</a> or <a href="recover.php?mode=password">password</a>?
				</li>
			</ul>
				
		</form>
	</div>
</div>