<section id="blog">
    <div class="container">
      <div class="row">
        <div class="heading text-center col-sm-8 col-sm-offset-2">
          <h2>Blog Posts</h2>
          <p>Latest updates on the happenings at Gigabyte Developers Incorporated, latest tutorials by our team regarding lots and lots of programming languages and some Software Development platforms. </p>
        </div>
      </div>
		<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fgigabytedevelopersinc%2F&tabs=timeline&width=382&height=400&small_header=false&adapt_container_width=false&hide_cover=false&show_facepile=true&appId" width="382" height="400" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		<a class="twitter-timeline" href="https://twitter.com/Enwokoma" data-widget-id="740163416065724417">Tweets by @Enwokoma</a>
		<a class="twitter-timeline" href="https://twitter.com/gigabytedevsinc" data-widget-id="740168844568842240">Tweets by @gigabytedevsinc</a>
        <div class="load-more">
          <a href="#" class="btn-loadmore" data-single_url="portfolio-single.html"><i class="fa fa-repeat"></i> Load More</a>
        </div>                
      </div>
    </div>
	  <div id="portfolio-single-wrap">
		  <div id="portfolio-single">
		  </div>
	  </div><!-- /#portfolio-single-wrap -->
  </section>