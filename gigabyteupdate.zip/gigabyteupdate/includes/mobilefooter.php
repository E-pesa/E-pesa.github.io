  <footer id="footer">
    <div class="footer-top">
      <div class="container text-center">
        <div class="footer-logo">
          <a href="index"><img class="img-responsive" src="./images/gigalogo.png" alt="Logo"></a>
        </div>
        <div class="social-icons">
          <ul>
            <li><a class="twitter" href="http://www.twitter.com/gigabytedevsinc" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a class="facebook" href="http://www.facebook.com/gigabytedevelopersinc" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a class="googleplus" href="http://plus.google.com/+GigabyteDevelopers" target="_blank"><i class="fa fa-google-plus"></i></a></li> 
            <li><a class="pinterest" href="http://pinterest.com/gigabytedevsinc" target="_blank"><i class="fa fa-pinterest"></i></a></li>
            <li><a class="skype" href="skype:emmanuel.nwokoma?call"><i class="fa fa-skype"></i></a></li>
            <li><a class="linkedin" href="http://www.linkedin.com/emmanuelnwokoma" target="_blank"><i class="fa fa-linkedin"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <p>Copyright &copy; 2016-2017 Gigabyte Developers Incorporated. All Rights Resevered</p>
          </div>
          <div class="col-sm-6">
          </div>
        </div>
      </div>
    </div>
  </footer>