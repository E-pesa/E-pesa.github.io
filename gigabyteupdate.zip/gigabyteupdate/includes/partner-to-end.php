<div class="partners">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 wow fadeInRightBig" data-wow-duration="1200ms" data-wow-delay="300ms">
					<h2 class="heading">Our Partners</h2></div>
				</div>
				<div class="col-xs-12"> 
					<div class="row">
						<nav>
							<ul>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="400ms"><a href="javascript:void()"><img src="./images/partners/partner01.jpg" alt="" class="img-responsives"></a></li>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="600ms"><a href="javascript:void()"><img src="./images/partners/partner02.jpg" alt="" class="img-responsives"></a></li>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="800ms"><a href="javascript:void()"><img src="./images/partners/mezuestudios.png" alt="" class="img-responsives"></a></li>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="1000ms"><a href="javascript:void(0)"><img src="./images/partners/carterax.png" alt="" class="img-responsives"></a></li>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="1200ms"><a href="javascript:void(0)"><img src="./images/partners/partner05.png" alt="" class="img-responsives"></a></li>
								<li class="col-md-2 col-sm-3 col-xs-6 wow flipInY" data-wow-duration="1000ms" data-wow-delay="1400ms"><a href="javascript:void(0)"><img src="./images/partners/partner06.jpg" alt="" class="img-responsives"></a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"> </div>
	<div class="container" id="contact" name="contact">
		<div class="row">
			<br>
			<h1 class="centered wow fadeInRightBig" data-wow-duration="1200ms" data-wow-delay="300ms">THANKS FOR VISITING US</h1>
			<div class="wow fadeInLeftBig" data-wow-duration="1200ms" data-wow-delay="400ms"><hr></div>
			<br>
			<br>
			<div class="col-lg-4 wow fadeInRightBig" data-wow-duration="1200ms" data-wow-delay="500ms">
				<h3>Contact Information</h3>
				<p><span class="icon icon-home wow fadeInUpBig" data-wow-duration="1200ms" data-wow-delay="600ms"></span> #40, Nnokwa Street, World Bank Housing Estate, Umuahia, Abia State. Nigeria <br/>
					<span class="icon icon-phone"></span> <a href="tel:+2348104309369">+234 810 430 9369 </a><br/>
					<span class="icon icon-mobile"></span> <a href="tel:+2347017236746">+234 701 723 6746 </a><br/>
					<span class="icon icon-envelop"></span> <a href="mailto:gigabytedevelopers@gmail.com" target="_blank"> gigabytedevelopers@gmail.com</a> <br/>
					<span class="icon icon-twitter"></span> <a href="http://www.twitter.com/gigabytedevsinc" target="_blank"> @gigabytedevsinc </a> <br/>
					<span class="icon icon-facebook"></span> <a href="http://www.facebook.com/gigabytedevelopersinc" target="_blank"> Gigabyte Developers Incorporated </a> <br/>
				</p>
			</div><!-- col -->
			<div class="col-lg-4 wow fadeInDown" data-wow-duration="1200ms" data-wow-delay="700ms">
				<h3>Newsletter</h3>
				<p>Register to our newsletter and be updated with the latests information regarding our services, offers and much more.</p>
				<p>
					<form class="form-horizontal" role="form">
						<div class="form-group">
						    <label for="inputEmail1" class="col-lg-4 control-label"></label>
						    <div class="col-lg-10">
								<input type="email" class="form-controlss" id="inputEmail1" placeholder="Email">
						    </div>
						</div>
						<div class="form-group">
						    <label for="text1" class="col-lg-4 control-label"></label>
						    <div class="col-lg-10">
								<input type="text" class="form-controls" id="text1" placeholder="Your Name">
						    </div>
						</div>
						<div class="form-group">
						    <div class="col-lg-10">
								<button type="submit" class="btns btns-success">Sign in</button>
						    </div>
						</div>
					</form><!-- form -->
				</p>
			</div><!-- col -->
			<div class="col-lg-4 wow fadeInUp" data-wow-duration="1200ms" data-wow-delay="800ms">
				<h3>Support Us</h3>
				<p>Do you love our work and would like us to achieve more? If, yes! Then why not support us to aid our continuity by simply clicking on the donate button below and donate to us. No amount is too small.<br/>Note: "God loves a cheerfull giver"!</p>
				<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=G35ZM2EKPVZ9Y"s type="submit" class="btns btns-success wow fadeInRightBig" data-wow-duration="1200ms" data-wow-delay="1000ms">Donate</a>
			</div><!-- col -->
		</div><!-- row -->
	</div>