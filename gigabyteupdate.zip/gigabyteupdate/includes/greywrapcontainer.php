<div id="greywrap">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 centered wow fadeInLeftBig" data-wow-duration="1000ms" data-wow-delay="300ms">
					<img class="img-responsive" src="./images/macbook.png" align="">
				</div>
				<div class="col-lg-4 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="400ms">
					<h2>Hire Us Now!</h2></div>
				<div class="col-lg-4 wow fadeInUpBig" data-wow-duration="1000ms" data-wow-delay="500ms">
				<p>Do you want our team at Gigabyte Developers Incorporated to do the work for you? Of course you want to, because we are awesome and 100% professional!. Here at Gigabyte Developers Incorporated, we work very hard every day to program lots of stuffs and to craft pixel perfect sites!. So, click on the button below to get started</p></div>
				<div class="wow fadeInRightBig" data-wow-duration="1000ms" data-wow-delay="600ms">
					<p>
					<a href="./contact" target="_blank" class="btns btns-success" style="float:center;">Contact Us</a>
<!-- <script style="display: inline-block" type="text/javascript" src="https://ko-fi.com/widgets/widget_2.js"></script><script type='text/javascript'>kofiwidget2.init('Buy Us a Coffee', '#028fcc', 'A561ND8');kofiwidget2.draw();</script> --></p>
				</div>				
				<div class="clearfix"></div>
			</div><!-- row -->
		</div>
		<br>
		<br>
	</div>
<div class="clearfix"> </div>